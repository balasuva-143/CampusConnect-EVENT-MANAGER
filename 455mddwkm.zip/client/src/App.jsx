import { useEffect, useState } from "react";
import "./App.css";

const defaultEvents = [
  {
    id: 1,
    title: "AI Hackathon",
    category: "Hackathon",
    date: "15 October 2026",
    venue: "Main Auditorium",
    description:
      "Build innovative AI solutions and compete with talented engineering students.",
    status: "Registration Open"
  },
  {
    id: 2,
    title: "Web Development Workshop",
    category: "Workshop",
    date: "18 October 2026",
    venue: "IT Laboratory",
    description:
      "Learn modern web development using HTML, CSS, JavaScript and React.",
    status: "Registration Open"
  },
  {
    id: 3,
    title: "Coding Contest",
    category: "Competition",
    date: "22 October 2026",
    venue: "Programming Laboratory",
    description:
      "Test your programming, logical thinking and problem-solving skills.",
    status: "Registration Open"
  },
  {
    id: 4,
    title: "Project Expo",
    category: "Project Expo",
    date: "28 October 2026",
    venue: "College Seminar Hall",
    description:
      "Showcase innovative academic and real-world engineering projects.",
    status: "Registration Open"
  },
  {
    id: 5,
    title: "Technical Symposium",
    category: "Symposium",
    date: "2 November 2026",
    venue: "Mahendra College Campus",
    description:
      "Present technical ideas, attend expert sessions and connect with students.",
    status: "Registration Open"
  }
];

function App() {
  const [events, setEvents] = useState(defaultEvents);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [showRegister, setShowRegister] = useState(false);
  const [showCreateEvent, setShowCreateEvent] = useState(false);
  const [message, setMessage] = useState("");

  const [registration, setRegistration] = useState({
    name: "",
    email: "",
    department: "",
    year: "",
    phone: ""
  });

  const [newEvent, setNewEvent] = useState({
    title: "",
    category: "",
    date: "",
    venue: "",
    description: ""
  });

  useEffect(() => {
    fetch("/api/events")
      .then((response) => response.json())
      .then((data) => {
        if (data.success && Array.isArray(data.events)) {
          setEvents(data.events);
        }
      })
      .catch(() => {
        console.log("Using default events");
      });
  }, []);

  const openRegistration = (event) => {
    setSelectedEvent(event);
    setShowRegister(true);
    setMessage("");
  };

  const closeRegistration = () => {
    setShowRegister(false);
    setSelectedEvent(null);
    setMessage("");
  };

  const handleRegistrationChange = (event) => {
    setRegistration({
      ...registration,
      [event.target.name]: event.target.value
    });
  };

  const handleRegistration = async (event) => {
    event.preventDefault();

    if (
      !registration.name ||
      !registration.email ||
      !registration.department ||
      !registration.year ||
      !registration.phone
    ) {
      setMessage("Please fill all fields.");
      return;
    }

    try {
      const response = await fetch("/api/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          eventId: selectedEvent.id,
          eventTitle: selectedEvent.title,
          ...registration
        })
      });

      const data = await response.json();

      if (data.success) {
        setMessage(data.message);

        setRegistration({
          name: "",
          email: "",
          department: "",
          year: "",
          phone: ""
        });
      } else {
        setMessage(data.message || "Registration failed.");
      }
    } catch {
      setMessage("Backend connection failed.");
    }
  };

  const handleNewEventChange = (event) => {
    setNewEvent({
      ...newEvent,
      [event.target.name]: event.target.value
    });
  };

  const createEvent = async (event) => {
    event.preventDefault();

    if (
      !newEvent.title ||
      !newEvent.category ||
      !newEvent.date ||
      !newEvent.venue ||
      !newEvent.description
    ) {
      alert("Please fill all event details.");
      return;
    }

    const localEvent = {
      id: Date.now(),
      ...newEvent,
      status: "Registration Open"
    };

    try {
      const response = await fetch("/api/events", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(newEvent)
      });

      const data = await response.json();

      if (data.success && data.event) {
        setEvents([...events, data.event]);
      } else {
        setEvents([...events, localEvent]);
      }
    } catch {
      setEvents([...events, localEvent]);
    }

    setNewEvent({
      title: "",
      category: "",
      date: "",
      venue: "",
      description: ""
    });

    setShowCreateEvent(false);

    alert("Event created successfully!");
  };

  return (
    <div className="app">

      {/* NAVBAR */}

      <nav className="navbar">

        <div className="brand">

          <div className="brand-logo">
            M
          </div>

          <div>
            <h2>CampusConnect</h2>
            <span>EVENT MANAGER</span>
          </div>

        </div>

        <div className="nav-links">
          <a href="#home">Home</a>
          <a href="#events">Events</a>
          <a href="#features">Features</a>
          <a href="#about">About</a>
        </div>

        <button
          className="create-button"
          onClick={() => setShowCreateEvent(true)}
        >
          + Create Event
        </button>

      </nav>

      {/* HERO */}

      <section className="hero" id="home">

        <div className="hero-content">

          <p className="eyebrow">
            MAHENDRA COLLEGE OF ENGINEERING, SALEM
          </p>

          <h1>
            Where Ideas
            <br />
            Become <span>Events.</span>
          </h1>

          <p className="hero-description">
            Discover, register and participate in exciting college
            events, technical competitions, workshops and project
            activities.
          </p>

          <div className="college-details">

            <div>
              <small>COLLEGE</small>
              <strong>
                Mahendra College of Engineering
              </strong>
            </div>

            <div>
              <small>LOCATION</small>
              <strong>Salem</strong>
            </div>

            <div>
              <small>DEPARTMENT</small>
              <strong>Information Technology</strong>
            </div>

          </div>

          <a
            href="#events"
            className="explore-button"
          >
            Explore Events →
          </a>

        </div>

        <div className="hero-card">

          <div className="hero-circle circle-one"></div>
          <div className="hero-circle circle-two"></div>
          <div className="hero-circle circle-three"></div>

          <div className="hero-card-content">

            <span>UPCOMING EVENT</span>

            <h2>AI Hackathon</h2>

            <p>15 October 2026</p>

            <div className="event-count">
              <strong>{events.length}</strong>
              <span>Events Available</span>
            </div>

          </div>

        </div>

      </section>

      {/* EVENTS */}

      <section
        className="events-section"
        id="events"
      >

        <div className="section-header">

          <div>

            <p className="eyebrow">
              COLLEGE ACTIVITIES
            </p>

            <h2>Upcoming Events</h2>

          </div>

          <p>
            Participate.
            <br />
            Collaborate.
            <br />
            Create something amazing.
          </p>

        </div>

        <div className="events-grid">

          {events.map((event) => (

            <article
              className="event-card"
              key={event.id}
            >

              <div className="event-card-top">

                <span className="category">
                  {event.category}
                </span>

                <span className="event-status">
                  Open
                </span>

              </div>

              <h3>{event.title}</h3>

              <p className="event-description">
                {event.description}
              </p>

              <div className="event-info">

                <div>
                  <small>DATE</small>
                  <strong>{event.date}</strong>
                </div>

                <div>
                  <small>VENUE</small>
                  <strong>{event.venue}</strong>
                </div>

              </div>

              <button
                className="register-button"
                onClick={() => openRegistration(event)}
              >
                Register Now →
              </button>

            </article>

          ))}

        </div>

      </section>

      {/* FEATURES */}

      <section
        className="features-section"
        id="features"
      >

        <div className="section-title">

          <p className="eyebrow">
            EVENT MANAGEMENT
          </p>

          <h2>Everything You Need</h2>

        </div>

        <div className="features-grid">

          <div className="feature-card">
            <span>01</span>

            <h3>Create Event</h3>

            <p>
              Create and publish college events
              with complete details.
            </p>
          </div>

          <div className="feature-card">
            <span>02</span>

            <h3>Team Creation</h3>

            <p>
              Create teams and add members for
              competitions and hackathons.
            </p>
          </div>

          <div className="feature-card">
            <span>03</span>

            <h3>Participants</h3>

            <p>
              View registered students and manage
              event participants.
            </p>
          </div>

          <div className="feature-card">
            <span>04</span>

            <h3>Event Status</h3>

            <p>
              Track upcoming, active, completed
              and closed events.
            </p>
          </div>

        </div>

      </section>

      {/* ABOUT */}

      <section
        className="about-section"
        id="about"
      >

        <div className="about-box">

          <p className="eyebrow">
            ABOUT THE PLATFORM
          </p>

          <h2>
            Built for
            <br />
            <span>College Communities.</span>
          </h2>

          <p>
            CampusConnect Event Manager helps
            students discover college activities,
            register for events, create teams and
            participate in technical programs.
          </p>

          <div className="about-stats">

            <div>
              <strong>{events.length}</strong>
              <span>Events</span>
            </div>

            <div>
              <strong>5+</strong>
              <span>Features</span>
            </div>

            <div>
              <strong>IT</strong>
              <span>Department</span>
            </div>

          </div>

        </div>

      </section>

      {/* FOOTER */}

      <footer>

        <div>

          <h3>CampusConnect</h3>

          <p>
            College Event Management Platform
          </p>

        </div>

        <div className="footer-center">

          <p>
            Mahendra College of Engineering
          </p>

          <p>
            Salem · Department of Information Technology
          </p>

        </div>

        <div className="footer-created">

          <span>WEBSITE</span>

          <strong>
            Created By Balamurugan
          </strong>

        </div>

      </footer>

      {/* REGISTRATION MODAL */}

      {showRegister &&
        selectedEvent && (

          <div
            className="modal-overlay"
            onClick={closeRegistration}
          >

            <div
              className="modal"
              onClick={(event) =>
                event.stopPropagation()
              }
            >

              <button
                className="close-button"
                onClick={closeRegistration}
              >
                ×
              </button>

              <p className="eyebrow">
                EVENT REGISTRATION
              </p>

              <h2>
                {selectedEvent.title}
              </h2>

              <p className="modal-description">
                Register for this college event.
              </p>

              <form
                onSubmit={handleRegistration}
              >

                <input
                  name="name"
                  placeholder="Full Name"
                  value={registration.name}
                  onChange={
                    handleRegistrationChange
                  }
                />

                <input
                  name="email"
                  type="email"
                  placeholder="Email Address"
                  value={registration.email}
                  onChange={
                    handleRegistrationChange
                  }
                />

                <input
                  name="department"
                  placeholder="Department"
                  value={
                    registration.department
                  }
                  onChange={
                    handleRegistrationChange
                  }
                />

                <select
                  name="year"
                  value={registration.year}
                  onChange={
                    handleRegistrationChange
                  }
                >

                  <option value="">
                    Select Year
                  </option>

                  <option value="1st Year">
                    1st Year
                  </option>

                  <option value="2nd Year">
                    2nd Year
                  </option>

                  <option value="3rd Year">
                    3rd Year
                  </option>

                  <option value="4th Year">
                    4th Year
                  </option>

                </select>

                <input
                  name="phone"
                  placeholder="Phone Number"
                  value={registration.phone}
                  onChange={
                    handleRegistrationChange
                  }
                />

                <button
                  type="submit"
                  className="submit-button"
                >
                  Submit Registration
                </button>

              </form>

              {message && (
                <div className="success-message">
                  {message}
                </div>
              )}

            </div>

          </div>
        )}

      {/* CREATE EVENT MODAL */}

      {showCreateEvent && (

        <div
          className="modal-overlay"
          onClick={() =>
            setShowCreateEvent(false)
          }
        >

          <div
            className="modal create-modal"
            onClick={(event) =>
              event.stopPropagation()
            }
          >

            <button
              className="close-button"
              onClick={() =>
                setShowCreateEvent(false)
              }
            >
              ×
            </button>

            <p className="eyebrow">
              ADMIN / ORGANIZER
            </p>

            <h2>Create New Event</h2>

            <p className="modal-description">
              Add a new event to the college
              event manager.
            </p>

            <form onSubmit={createEvent}>

              <input
                name="title"
                placeholder="Event Name"
                value={newEvent.title}
                onChange={
                  handleNewEventChange
                }
              />

              <input
                name="category"
                placeholder="Category e.g. Hackathon"
                value={newEvent.category}
                onChange={
                  handleNewEventChange
                }
              />

              <input
                name="date"
                placeholder="Event Date"
                value={newEvent.date}
                onChange={
                  handleNewEventChange
                }
              />

              <input
                name="venue"
                placeholder="Venue"
                value={newEvent.venue}
                onChange={
                  handleNewEventChange
                }
              />

              <textarea
                name="description"
                placeholder="Event Description"
                value={
                  newEvent.description
                }
                onChange={
                  handleNewEventChange
                }
              ></textarea>

              <button
                type="submit"
                className="submit-button"
              >
                Create Event
              </button>

            </form>

          </div>

        </div>
      )}

    </div>
  );
}

export default App;